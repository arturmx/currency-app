import './footer.scss'
// import { useState } from 'react';
// import Selection from '../Selection'

const Footer = function() {

    // nie działa
    // < Selection />
    // Selection();

    return (
        
        <div className="footer">
            <p className="footer__p">Indicative Exchange Rate</p>
            <p className="footer__rate">1 {} = 0.7367 USD</p>
        </div>
        )
}
export default Footer